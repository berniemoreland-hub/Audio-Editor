BERNIE WAVE EDITOR
Version 2.0 · Build 014

SIMPLE INSTALL
1. Extract this ZIP.
2. Double-click INSTALL_BERNIE_WAVE_EDITOR.bat.
3. It will install Node.js LTS automatically with Windows Package Manager if needed, build Bernie Wave Editor, and launch Bernie Wave Editor Setup.exe.
4. Follow the installer prompts.

The generated installer always uses the same filename:
Bernie Wave Editor Setup.exe

The app is intentionally single-track and designed around a fast VoxPro-style record/edit/play workflow.

Build 005 additions:
- A key jogs the playhead/cursor left by 0.1 second per key repeat.
- L key jogs the playhead/cursor right by 0.1 second per key repeat.
- Holding A or L continuously jogs in that direction.

Build 004 additions:
- Live waveform draws and grows while recording.
- Export dropdown supports WAV or MP3 (192 kbps).


BUILD 014 — AUTOMATIC WINDOWS INSTALLER
This project now includes .github/workflows/build-windows.yml.
Push the project to GitHub and GitHub Actions will build:
Bernie Wave Editor Setup.exe

See GITHUB_BUILD_SETUP.txt for the one-time setup steps.
